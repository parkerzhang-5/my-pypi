from .web import run_shell as _run_shell
from .web import help as helps

# 对外暴露接口，直接转发
def run_shell(cmd):
    _run_shell(cmd)
def help():
      helps()

