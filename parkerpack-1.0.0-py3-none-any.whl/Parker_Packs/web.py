import os
def run_shell(web):
    os.system(web)
def help():
    print("Parker_Packs.run_shell(code)")
    print("my mail is:hjk990109@gmail.com\n我的电子邮箱是:hjk990109@gmail.com")
