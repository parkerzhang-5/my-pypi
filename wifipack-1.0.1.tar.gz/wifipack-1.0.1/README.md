# Parker_Packs
[![PyPI](https://img.shields.io/pypi/v/musicpack.svg)](https://pypi.org/project/musicpack/)
[![Python Version](https://img.shields.io/pypi/pyversions/musicpack)](https://pypi.org/project/musicpack/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
## 欢迎
欢迎，朋友
你是不是还被在上电脑课的网络是内网苦恼
没事
这个python库可以帮你
帮助是wifipack.help()
下载 pip install wifipack
