# musicpack
[![PyPI](https://img.shields.io/pypi/v/musicpack.svg)](https://pypi.org/project/musicpack/)
[![Python Version](https://img.shields.io/pypi/pyversions/musicpack)](https://pypi.org/project/musicpack/)
[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE)
Light‑weight CLI & Python‑SDK for Cloudflare‑Worker音乐后端管理。不在本地保存密钥，每次调用必须指定域名.

## 功能清单
- JSON文件批量上传歌曲
- 交互式单首添加音乐
- 根据UUID(musicId)删除单条曲目
- 清空全部曲目（手动确认防止误删）
- 列出本人上传曲目，用来获取musicId
- 支持系统环境变量快速切换账号
- 无本地持久化密钥，凭证只在内存临时存在
- Python版本 >=3.10

## 安装
    pip install musicpack

源码本地安装
    git clone https://github.com/你的用户名/musicpack.git
    cd musicpack
    pip install .

## 命令行使用
### 查看帮助
    musicpack -h

|参数|说明|
|---|---|
|-t,--template|导出批量上传JSON模板|
|-f,--file FILE|读取JSON文件批量上传|
|-add|交互式单首添加歌曲|
|-del MUSICID|使用musicId删除单首音乐|
|-delall|清空全部歌曲，需要输入yes确认|
|-list|列出自己上传所有曲目，拿到musicId|
|-k,--apikey KEY|机器人32位API‑Key，优先读取环境变量 MUSICPACK_APIKEY|
|-u,--url URL|Worker域名，格式 https://xxx.workers.dev，优先读取环境变量 MUSICPACK_ENDPOINT|

### 常用示例
    #生成模板
    musicpack -t
    #列出曲目
    musicpack -list -k "APIKEY" -u "https://xxx.workers.dev"
    #批量上传
    musicpack -f musics.json -k "APIKEY" -u "https://xxx.workers.dev"
    #单首添加
    musicpack -add -k "APIKEY" -u "https://xxx.workers.dev"
    #删除单条
    musicpack -del "uuid" -k "APIKEY" -u "https://xxx.workers.dev"
    #清空全部
    musicpack -delall -k "APIKEY" -u "https://xxx.workers.dev"

## 多账号切换方式
### 方式1：每次手动填写参数（推荐）
直接修改‑k和‑u的值，本地不会留存任何信息。

### 方式2：环境变量（仅当前终端生效，关闭终端自动清除）
Windows PowerShell
    $env:MUSICPACK_APIKEY="keyA"
    $env:MUSICPACK_ENDPOINT="https://a.workers.dev"
    musicpack -list

Linux/macOS
    export MUSICPACK_APIKEY="keyA"
    export MUSICPACK_ENDPOINT="https://a.workers.dev"
    musicpack -list

## Python代码内调用
    from musicpack.main import batch_upload,single_add,delete_single,delete_all,list_music

    #切换账号只修改下面两项
    API_KEY = "32位APIKEY"
    ENDPOINT = "https://xxx.workers.dev"

    #列出曲目
    print(list_music(API_KEY,ENDPOINT))

    #单首新增
    song={
        "songName":"",
        "authorName":"",
        "thumbnailUrl":"",
        "audioUrl":"",
        "description":"",
        "genre":"Brazil‑Funk"
    }
    print(single_add(API_KEY,ENDPOINT,song))

    #批量上传
    # batch_upload(API_KEY,ENDPOINT,song_list)
    #删除单条
    # delete_single(API_KEY,ENDPOINT,"uuid")
    #全部清空
    # delete_all(API_KEY,ENDPOINT)

### 环境变量方式（密钥不写在源码内）
    import os
    from musicpack.main import list_music
    API_KEY = os.getenv("MUSICPACK_APIKEY")
    ENDPOINT = os.getenv("MUSICPACK_ENDPOINT")
    print(list_music(API_KEY,ENDPOINT))

## 安全说明
1. 本库不会生成任何本地配置文件，密钥不会写入硬盘。
2. 凭证只在程序运行时存在内存，程序结束自动销毁。
3. 切换多个机器人账号只更换apikey和域名参数即可。
4. 不要在公开代码里明文写密钥，优先使用环境变量.

## Github地址
https://github.com/你的Github用户名/musicpack
## License
MIT