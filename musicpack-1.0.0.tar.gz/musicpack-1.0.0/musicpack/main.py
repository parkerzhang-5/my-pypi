import requests
import json
import argparse
import os

def get_env_config():
    """读取系统环境变量，不写入任何本地文件"""
    env_api = os.getenv("MUSICPACK_APIKEY", "")
    env_url = os.getenv("MUSICPACK_ENDPOINT", "")
    return env_api, env_url

def batch_upload(api_key: str, endpoint: str, music_list: list):
    """
    Python代码调用：批量上传音乐
    :param api_key:机器人账号32位API‑Key
    :param endpoint: Worker站点域名，例如 https://xxx.xxx.workers.dev
    :param music_list:歌曲列表数组
    :return: 接口返回json字典
    """
    url = f"{endpoint}/api/batchmusic"
    payload = {
        "apiKey": api_key,
        "musicList": music_list
    }
    res = requests.post(url, json=payload, timeout=30)
    return res.json()

def gen_template():
    """输出JSON模板"""
    template = [
        {
            "songName": "歌曲名称",
            "authorName": "作者",
            "thumbnailUrl": "封面图片链接",
            "audioUrl": "音频直链",
            "description": "备注、发布时间",
            "genre": "Brazil‑Funk"
        }
    ]
    print(json.dumps(template, indent=2, ensure_ascii=False))

def cli_main():
    env_api, env_url = get_env_config()
    parser = argparse.ArgumentParser(description="musicpack批量上传工具，不保存任何密钥至本地，切换账号直接修改参数")
    parser.add_argument("-t", "--template", action="store_true", help="导出JSON模板")
    parser.add_argument("-f", "--file", type=str, help="指定歌曲json文件路径")
    parser.add_argument("-k", "--apikey", type=str, default=env_api, help="机器人API‑Key，优先读取环境变量MUSICPACK_APIKEY")
    parser.add_argument("-u", "--url", type=str, default=env_url, help="Worker站点地址，优先读取环境变量MUSICPACK_ENDPOINT")
    args = parser.parse_args()

    if args.template:
        gen_template()
        return

    if not args.file:
        print("错误：请使用 -f 指定json歌曲文件路径")
        return
    if not args.apikey or not args.url:
        print("错误：缺少API‑Key或者站点地址。\n方式1：命令行增加 -k 和 -u 参数；\n方式2：配置系统环境变量 MUSICPACK_APIKEY、MUSICPACK_ENDPOINT")
        return

    with open(args.file, "r", encoding="utf-8") as f:
        music_data = json.load(f)
    ret = batch_upload(args.apikey, args.url, music_data)
    print(json.dumps(ret, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    cli_main()