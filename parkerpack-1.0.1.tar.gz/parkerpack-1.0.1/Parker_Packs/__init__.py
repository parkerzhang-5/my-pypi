from .web import run_shell as _run_shell
from .web import help as helps
from .web import test as tests
from .web import otest as otests

__version__ = "1.0.1"
