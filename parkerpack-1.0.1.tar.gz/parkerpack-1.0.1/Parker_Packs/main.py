from .web import run_shell as _run_shell
from .web import help as helps
from .web import test as tests
from .web import otest as otests


# 对外暴露接口，直接转发
def run_shell(cmd):
    _run_shell(cmd)
def help():
      helps()
def test():
    print("等下错误是正常的，不要慌张")
    tests()

