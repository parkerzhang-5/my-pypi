import os
import time
def run_shell(web):
    os.system(web)
def help():
    print("Parker_Packs.run_shell(code)")
    print("Parker_Packs.tests()")
    print("my mail is:hjk990109@gmail.com\n我的电子邮箱是:hjk990109@gmail.com")
def otest():
    otest()
def test():
    print("等下有错误是正常，不然没下完")
    print(3)
    time.sleep(1)
    print(2)
    time.sleep(1)
    print(1)
    time.sleep(1)
    otest()

